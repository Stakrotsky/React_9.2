import { createStore, applyMiddleware, combineReducers } from 'redux';
import { thunk } from 'redux-thunk';
import { tasksReducer, uiReducer, filterReducer } from './reducers/index';

const rootReducer = combineReducers({
	tasks: tasksReducer,
	ui: uiReducer,
	filters: filterReducer,
});

export const store = createStore(rootReducer, applyMiddleware(thunk));
